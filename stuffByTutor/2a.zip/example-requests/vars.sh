#!/bin/bash
#vars file, to be sourced from the other scripts

#url to REST-Webservice
SERVER_URL=http://localhost/wmephp/
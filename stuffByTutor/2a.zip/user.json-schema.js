{"description":"A user of the PhotonPainter application landscape.",
 "type":"object",
 "properties":{
	"id":{"type":"number","description":"ID of this user."},
	"login":{"type":"string","description":"The user's account name."},
	"password":{"type":"string","description":"The user's password. Used only for submitting authentication data."}
	}
}